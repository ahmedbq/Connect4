package com.mobiledevelopment.ahmed.connect4;

public class Connect4 {
    public static final int rowNumber = 6;
    public static final int colNumber = 7;
    private int turn;
    private int [][] game;

    private int Player1ScoreTrack = 0;
    private int Player2ScoreTrack = 0;
    private int TieScoreTrack = 0;

    public Connect4( ) {
        game = new int[rowNumber][colNumber];
        resetGame( );
    }

    public int play( int row, int col ) {
        int currentTurn = turn;
        if( row >= 0 && col >= 0 && row < (rowNumber) && col < colNumber
                && game[0][col] == 0 ) {
            /*changed last restriction to game[0][col] == 0 so that you can
            * click the same button multiple times and at the same time stop
            * the game from changing the first value on top.*/
            /*Changed this to fit setButtonText*/
            int r;

            for (r = Connect4.rowNumber-1; r > -1; r--)
            {
                if (game[r][col] == 0)
                {
                    game[r][col] = turn;

                    break;
                }
            }

            if( turn == 1)
            {turn = 2;}
            else if (turn == 2)
            {turn = 1;}
            return currentTurn;
        }
        else
            return 0;
    }

    public int whoWon( ) {
        int rows = checkRows( );
        if ( rows > 0 )
            return rows;
        int columns = checkColumns( );
        if( columns > 0 )
            return columns;
        int diagonals = checkDiagonals( );
        if( diagonals > 0 )
            return diagonals;
        return 0;
    }

    /*Made restrictions so that r!=0 and c!=SIDE-1 because there
    * were problems with the first row and column.*/

    protected int checkRows( ) {
        for (int r = 0; r < rowNumber; r++) {
            int count = 0;
            for (int c = 1; c < colNumber; c++) {
                if ((game[r][c] != 0 && c != rowNumber-1)&&
                        game[r][c] == game[r][c - 1]) {
                    count++;
                } else {
                count = 1;
                }
                if (count >= 4) {
                    return game[r][c];
            }

        }
    }

        return 0;
    }

    protected int checkColumns( ) {
        for (int c = 0; c < colNumber; c++) {
            int count = 0;

            for (int r = 1; r < rowNumber; r++) {
                if ((game[r][c] != 0 /*&& r != 0*/) &&
                        game[r][c] == game[r - 1][c]) {
                    count++;

                } else {
                    count = 1;
                }
                if (count >= 4) {
                    return game[r][c];
                }

            }
        }
        return 0;
    }

    protected int checkDiagonals( ) {
        final int maxx = rowNumber;
        final int maxy = colNumber;

            int[][] directions = {{1,0}, {1,-1}, {1,1}, {0,1}};
            for (int[] d : directions) {
                int dx = d[0];
                int dy = d[1];
                for (int x = 0; x < maxx; x++) {
                    for (int y = 0; y < maxy; y++) {
                        int lastx = x + 3*dx;
                        int lasty = y + 3*dy;
                        if (0 <= lastx && lastx < maxx && 0 <= lasty && lasty < maxy) {
                            int w = game[x][y];
                            if (w != 0 && w == game[x+dx][y+dy]
                                    && w == game[x+2*dx][y+2*dy]
                                    && w == game[lastx][lasty]) {
                                return w;
                            }
                        }
                    }
                }
            }
        return 0; // no winner
    }


    public boolean canNotPlay( ) {
        boolean result = true;
        /*In reality you only need to check the first row*/
            for( int col = 0; col < colNumber; col++ )
                if ( game[0][col] == 0 )
                    result = false;
        return result;
    }

    public boolean isGameOver( ) {
        return canNotPlay( ) || ( whoWon( ) > 0 );
    }

    public void resetGame( ) {
        for (int row = 0; row < rowNumber; row++)
            for( int col = 0; col < colNumber; col++ )
                game[row][col] = 0;
        turn = 1;
    }

    public String result( ) {
        if( whoWon( ) > 0 ) {
            if (whoWon() == 1)
            {
                Player1ScoreTrack++;
            }
            else if (whoWon() == 2)
            {
                Player2ScoreTrack++;
            }

            return "\n\nPlayer " + whoWon() + " won";
        }
        else if( canNotPlay( ) )
            return "Tie Game\n\n\nPlayer 1 Wins: " + Player1ScoreTrack + "\nPlayer 2 Wins: " + Player2ScoreTrack + "\nTie: " + TieScoreTrack++;
        else
            return "Play! Click any spot on a column to slide your piece in!\n\nPlayer 1 Wins: " + Player1ScoreTrack + "\nPlayer 2 Wins: " + Player2ScoreTrack + "\nTie: " + TieScoreTrack;
    }
}